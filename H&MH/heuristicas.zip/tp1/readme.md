Para executar o tp1, execute o seguinte comando:

		python3 <problema> <algoritmo> <entrada>
	
	ex:
		python3 tsp simulated_annealing inputs/mochila_4_20.txt
		
> Se preferir, o bash 'heuristic.sh' pode ser usado para determinar os argumentos e executar o programa.

Os algoritmos disponíveis são:
	
	* simulated_annealing
	* tabusearch
	
Os problemas disponíveis são:

	* tsp
	* knapsack
	
Ao fim da execução, o programa printará no terminal o resultado obtido pelo algoritmo !!



By: Davi dos Reis de Jesus
